#include <vector>
#include <string>
#include <stdio.h>
#include <iostream>

using namespace std;

class Vec{
	public:
		string str; // string to be held
		int indexInAlpha; //index of that string in alphaHeap
		int indexInLength;	//index of that string in lengthHeap

		//==Functions==//
		Vec(string s, int i, int n);
};
		
class Dish{
	private:
		//vector<string> stringVec;
		vector<Vec> stringVec1;
		vector<int> alphaHeap; // minHeap: Holds the alphabetical indeces of the strings 
		vector<int> lengthHeap; // minHeap: Holds the indeces of the lengths of the strings

	public:
		//==Dish Functions==//
		int insert(string s);	
		int find(string s);
		bool capitalize(int k);
		bool allcaps(int k);
		bool truncate(int k, int i);

		//==Heap Functions==//
		void minHeapify(bool heap, int index);	
		void swap(bool heap, int i, int smallest);
		void decreaseKey(bool heap, int index);
		void printHeaps();
		string getfirst();
		string getshortest();
		//int findInAlphaHeap(int k);
		//int findInLengthHeap(int k);
};
