#include "Dish.h"
#include <vector>
#include <string>
#include <stdio.h>
#include <iostream>

using namespace std;

int Dish::insert(string s){
	//int index = stringVec.size();
	int index = stringVec1.size();
	stringVec1.push_back(Vec(s, index, index));
	//stringVec.push_back(s);
	//int index = stringVec.size()-1;

	alphaHeap.push_back(index); // bool heap = false
	lengthHeap.push_back(index); //bool heap = true
	decreaseKey(false, index);
	decreaseKey(true, index);
	return index; 
}

int Dish::find(string s){
	for(int i=0; i<stringVec1.size(); i++){
	//for(int i=0; i<stringVec.size(); i++){
		//if(stringVec[i] == s) {
		if(stringVec1[i].str ==s){
			return i;
		}
	}
	return -1;
}

/*int Dish::findInAlphaHeap(int k){ //must replace with container later for efficiency
	for(int i=0; i<alphaHeap.size(); i++){
		if(alphaHeap[i] == k) {
			return i;
		}
	}
	return -1;
}

int Dish::findInLengthHeap(int k){ //must replace with container later for efficiency
	for(int i=0; i<lengthHeap.size(); i++){
		if(lengthHeap[i] == k) {
			return i;
		}
	}
	return -1;
}*/

bool Dish::capitalize(int k){
	if(k<stringVec1.size()){
	//if(k<stringVec.size()){
		stringVec1[k].str[0] = ::toupper(stringVec1[k].str[0]);
		//stringVec[k][0] = ::toupper(stringVec[k][0]);
		//decreaseKey(false, findInAlphaHeap(k)); // bool heap = false, only changes alphaHeap
		decreaseKey(false, stringVec1[k].indexInAlpha);
//**********NEED TO CHANGE TO stringVec1[k].indexInAlpha**************//
		return true;
	} else {
		return false; // Index does not exist
	}
}

bool Dish::allcaps(int k){
	if(k<stringVec1.size()){
	//if(k<stringVec.size()){
		for(int i=0; i<stringVec1[k].str.length(); i++){
		//for(int i=0; i<stringVec[k].length(); i++){
			stringVec1[k].str[i] = ::toupper(stringVec1[k].str[i]);
			//stringVec[k][i] = ::toupper(stringVec[k][i]);
		}
		//decreaseKey(false, findInAlphaHeap(k));
		decreaseKey(false, stringVec1[k].indexInAlpha);
//**********NEED TO CHANGE TO stringVec1[k].indexInAlpha**************//
		return true;
	} else {
		return false; // Index does not exist
	}	
}

bool Dish::truncate(int k, int i){
	if(k<stringVec1.size()){
	//if(k<stringVec.size()){
		if(i>stringVec1[k].str.length()){
		//if(i>stringVec[k].length()){
			return true; // If index is greater than the length of string
		} else{
			stringVec1[k].str = stringVec1[k].str.substr(0, i);
			//stringVec[k] = stringVec[k].substr(0, i);
			//decreaseKey(true, findInLengthHeap(k));
			decreaseKey(true, stringVec1[k].indexInLength);
			//decreaseKey(false, findInAlphaHeap(k));
			decreaseKey(false, stringVec1[k].indexInAlpha);
			return true;
		}
	} else {
		return false; // Index does not exist
	}
}

string Dish::getfirst(){
	//return stringVec[alphaHeap[0]];
	return stringVec1[alphaHeap[0]].str;
}

string Dish::getshortest(){
	//return stringVec[lengthHeap[0]];
	return stringVec1[lengthHeap[0]].str;
}

//====================HEAP FUNCTIONS====================//

void Dish::minHeapify(bool heap, int i){	
	int left, right, smallest;

	left = (2*i)+1;
	right = (2*i)+2;

	if(left <= alphaHeap.size() && ((heap==false && stringVec1[alphaHeap[left]].str<stringVec1[alphaHeap[i]].str) || (heap==true && stringVec1[lengthHeap[left]].str.length()<stringVec1[lengthHeap[i]].str.length()))){
	/*if(left <= alphaHeap.size() && ((heap==false && stringVec[alphaHeap[left]]<stringVec[alphaHeap[i]]) || (heap==true && stringVec[lengthHeap[left]].length()<stringVec[lengthHeap[i]].length()))){*/
		smallest = left;
	}
	else {
		smallest = i;
	}

	if(right<= alphaHeap.size() && ((heap==false && stringVec1[alphaHeap[right]].str>stringVec1[alphaHeap[smallest]].str) || (heap==true && stringVec1[lengthHeap[right]].str.length()>stringVec1[lengthHeap[smallest]].str.length()))){
	/*if(right<= alphaHeap.size() && ((heap==false && stringVec[alphaHeap[right]]>stringVec[alphaHeap[smallest]]) || (heap==true && stringVec[lengthHeap[right]].length()>stringVec[lengthHeap[smallest]].length()))){*/
		smallest = right;
	}

	if(smallest != i){
		swap(heap, i, smallest);
		minHeapify(heap, smallest);
	}
}

void Dish::swap(bool heap, int i, int smallest){
  int temp = 0, temp2 = 0;
	if(heap==false){
		temp = alphaHeap[i];
		alphaHeap[i] = alphaHeap[smallest];
		alphaHeap[smallest] = temp;

		temp2 = stringVec1[alphaHeap[i]].indexInAlpha;
		stringVec1[alphaHeap[i]].indexInAlpha =  stringVec1[alphaHeap[smallest]].indexInAlpha; //Added to change container index values
		stringVec1[alphaHeap[smallest]].indexInAlpha = temp2;
	} else {
		temp = lengthHeap[i];
		lengthHeap[i] = lengthHeap[smallest];
		lengthHeap[smallest] = temp;

		temp2 =  stringVec1[lengthHeap[i]].indexInLength;
		stringVec1[lengthHeap[i]].indexInLength =  stringVec1[lengthHeap[smallest]].indexInLength;
		stringVec1[lengthHeap[smallest]].indexInLength = temp2;
	}
}

void Dish::decreaseKey(bool heap, int index){
	int parentIndex, temp;
	
	if(index!=0){
		parentIndex = (index - 1)/2;
		if((heap == false && stringVec1[alphaHeap[parentIndex]].str > stringVec1[alphaHeap[index]].str) || (heap==true && stringVec1[lengthHeap[parentIndex]].str.length() > stringVec1[lengthHeap[index]].str.length())){
	/*	if((heap == false && stringVec[alphaHeap[parentIndex]] > stringVec[alphaHeap[index]]) || (heap==true && stringVec[lengthHeap[parentIndex]].length() > stringVec[lengthHeap[index]].length())){*/
			swap(heap, index, parentIndex);
			decreaseKey(heap, parentIndex);
		}
	}

//need to set indexinalpha and index in length
}

void Dish::printHeaps(){
	/*cout << "String vector: " << endl;
	for(int i=0; i<stringVec.size(); i++){
		cout << "String " << i << ": " << stringVec[i] << endl;
	}*/
	cout << "String vector1: " << endl;
	for(int i=0; i<stringVec1.size(); i++){
		cout << "String " << i << ": " << stringVec1[i].str << endl;
		//		cout << "alphaheap index " << ": " << stringVec1[i].indexInAlpha << endl;
		//	cout << "lengthheap index " << ": " << stringVec1[i].indexInLength << endl;
	}
	cout << "Alphabet vector: " << endl;
	for(int i=0; i<alphaHeap.size(); i++){
		cout << "Index " << i << ": " << alphaHeap[i] << endl;
	}
	cout << "Length vector: " << endl;
	for(int i=0; i<lengthHeap.size(); i++){
		cout << "Index " << i << ": " << lengthHeap[i] << endl;
	}
}

//====================CONTAINER FUNCTIONS====================//
Vec::Vec(string s, int i, int n){
	str = s;
	indexInAlpha = i;
	indexInLength = n;
}
