To run my program just make with the make command and execute with ./Dish
I have included 2 test cases, each with 10 words.
First test case:
insert octopus
insert airplane
insert panda
insert no
insert lllooonnnggg
insert thanksgiving
insert home
insert candy
insert zebra
insert run
capitalize home
allcaps airplane
truncate lllooonnnggg 1
printheaps
getshortest
getfirst

This test case inserts 10 words then changes home to Home, airplane to AIRPLANE, and lllooonnnggg to l.
Once done, it prints the original string vector and each heap. The heaps are printed in terms of the
indeces within them and you can refer to the orignial string vector printed to know which string
each index is referring to. It then prints the shortest and first alphabetically.

Second test case:
insert thanks
insert giving
truncate giving 3
insert turkey
insert stuffing
capitalize giving
capitalize turkey
insert cranberry
insert sauce
allcaps sauce
insert gravy
insert family
insert gobble
insert fall
printheaps
getshortest
getfirst

This test case is similar to the first but it does the operations in between insertions of words.
It prints the heaps afterwards the same as done in the first case. 
