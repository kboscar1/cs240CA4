#include "Dish.h"
#include <stdio.h>
#include<iostream>
using namespace std;

int main(){
	Dish d;
	Dish d1;
	//	int break = 0;
	string truncateInt;
	string input, insert, find, capitalize, allcaps, truncate;
	//	cout << "Enter a command: [quit, insert, find, capitalize, allcaps, truncate, getshortest, getfirst]" << endl;
	// cin >> input;

	/*	while(1){
	  input = "";
	  cout << "Enter one command only and hit enter. You will be prompted after to enter a word or index." << endl;
	     cout << "Enter a command: [quit, insert, find, capitalize, allcaps, truncate, getshortest, getfirst]" << endl;
	     cin >> input;
	     if(input =="insert"){
	       cout << "Enter word to insert:";
	       cin >> insert;
	       d.insert(insert);
	     } else if (input == "find"){
	       int findRet;
	       cout << "Enter word to find:";
	       cin >> find;
	       findRet = d.find(find);
	       if(findRet == -1){
		 cout << "string not found" << endl;
	       } else {
		 cout << "string found at index " << findRet << endl;
	       }
	     } else if (input=="capitalize"){
	       cout << "Enter index to capitalize:";
	       cin >> capitalize;
	       d.capitalize(stoi(capitalize));
	     } else if (input=="allcaps"){
	       cout << "Enter index to put in caps:";
	       cin >> allcaps;
	       d.allcaps(stoi(allcaps));
	     } else if (input=="truncate"){
	       cout << "Enter index to truncate:";
	       cin >> truncate;
	       cout << "Enter amount to truncate to:";
	       cin >> truncateInt;
	       d.truncate(stoi(truncate), stoi(truncateInt));
	     } else if(input=="getshortest"){
	       cout << "Shortest is " << d.getshortest() << endl;
	     } else if (input=="getfirst"){
	       cout << "First is " << d.getfirst() << endl;
	     } else if (input=="quit"){
	       break;
	     } else {
	       cout << "Not a command. Try again" << endl;
	     }
	     }*/
	cout <<"--------TEST CASE #1:--------" << endl;
	d.insert("octopus"); //0
	d.insert("airplane"); //1
	d.insert("panda"); //2
	d.insert("no"); //3
	d.insert("lllooonnnggg");//4
	d.insert("thanksgiving");//5
	d.insert("home");//6	
	d.insert("candy");//7
	d.insert("zebra");//8
	d.insert("run");//9
	d.capitalize(6);
	d.allcaps(1);
	d.truncate(4, 1);
	d.printHeaps();
	cout << endl;
	cout << "Shortest: " <<  d.getshortest() << endl;
	cout << "First alphabetically: " << d.getfirst() << endl;



	cout <<"--------TEST CASE #2:--------" << endl;
	d1.insert("thanks");
	d1.insert("giving");
	d1.truncate(1, 3);
	d1.insert("turkey");
	d1.insert("stuffiing");
	d1.capitalize(1);
	d1.capitalize(0);
	d1.insert("cranberry");
	d1.insert("sauce");
	d1.allcaps(5);
	d1.insert("gravy");
	d1.insert("family");
	d1.insert("gobble");
	d1.insert("fall");
	d1.printHeaps();
	cout << endl;
	cout << "Shortest: " <<  d1.getshortest() << endl;
	cout << "First alphabetically: " << d1.getfirst() << endl;

	//	string a = "Giv";
	//	string b = "SAUCE";
	//	if(a<b) cout << "less than" << endl;

	return 0;
}
